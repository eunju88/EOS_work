// express는 nodejs 기반의 웹 프레임 워크다.
// 해당 파일 경로에서 npm install express
// 파일 변경 시 마다 자동으로 서버 재시작을 해주고 싶다면 npm install supervisor -g
const express = require('express');

const app = express();

// EOS
// npm install eosjs
// npm install node-fetch
const { Api, JsonRpc } = require('eosjs');
const fetch = require('node-fetch');
const { JsSignatureProvider } = require('eosjs/dist/eosjs-jssig');
const { TextDecoder, TextEncoder } = require('util');

// express body-parser
app.use(express.urlencoded({extended : false}));

// 템플릿 엔진 선언
app.set('view engine', 'ejs');
app.set('views', './views');

// '/' 경로에 Router
app.get('/', function(req, res){
    //res.send('Hi World!');
    res.render('index');
})

// login
app.use('/login', function(req, res){
    var method = req.method;

    if(method == "GET"){
        res.render('login');
    }else{
        var privatekey = req.param('privatekey');
        var apiUrl = req.param('api_url');
        var account = req.param('account');

        console.log(privatekey);
        console.log(apiUrl);
        console.log(account);
/*
        const privateKeys = '';
        const signatureProvider = new JsSignatureProvider();
        const rpc = new JsonRpc('http://jungle2.cryptolions.io:80', { fetch });
        const eos = new Api({ rpc, signatureProvider, textDecoder: new TextDecoder(), textEncoder: new TextEncoder() });

        */
    }
})

app.listen(3000, () => {
    console.log('Server running at localhost:3000');
})